import { Actions } from 'flummox';

export default class PointsActions extends Actions {

  login(data) {
    return data;
  }

}
