export { default as getSmallIcon } from './car/small.js';
export { default as getBigIcon, getIcon } from './car/big.js';
